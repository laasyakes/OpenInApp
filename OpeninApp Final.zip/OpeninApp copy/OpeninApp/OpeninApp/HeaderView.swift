import SwiftUI

struct HeaderView: View {
    var body: some View {
        HStack {
            Text("Dashboard")
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(.white)
                .offset(y: -40)
            
            Spacer()
            
            Text("⚙️") // Settings emoji
                .font(.title)
                .foregroundColor(.white)
                .padding(.trailing, 10)
                .padding(.top, -60)
        }
        .padding(.horizontal)
        .padding(.top, 60)
        .background(Color.blue)
    }
}
