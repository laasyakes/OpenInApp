import SwiftUI

struct GreetingView: View {
    var body: some View {
        VStack {
            HStack {
                Text("Good Morning!")
                    .font(.title2)
                    .foregroundColor(.gray)
                Spacer()
            }
            HStack(spacing: 0) { // Added spacing: 0 to remove default spacing between texts
                Text("Laasya")
                    .fontDesign(.rounded)
                    .font(.largeTitle)
                    .fontWeight(.semibold)
                    .foregroundColor(.black)
                    .padding(.leading, -200)
                    .padding(.top, -20)
                
                Text("👋") // Waving emoji
                    .font(.largeTitle)
                    .padding(.leading, -80)
                    .padding(.top, -20)
            }
            .padding()
            
            // Add the "Graph" image
            Image("Graph")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .padding(.top, 20) // Adjust top padding as needed
            
            // Horizontally scrollable square boxes
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 20) {
                    BoxView(emoji: "👆🏻", count: "8", label: "Today Clicks")
                    BoxView(emoji: "👆🏻", count: "1822", label: "Total Clicks")
                    BoxView(emoji: "📍", count: "Karachi", label: "Top Location")
                    BoxView(emoji: "🌐", count: "Direct", label: "Top Source")
                }
                .padding(.horizontal, 20) // Padding around the scrollable content
            }
            .padding(.top, 20) // Adjust top padding as needed
            
            // Button for Analytics
            Button(action: {
                // Action for tapping the Analytics button
            }) {
                HStack(spacing: 10) {
                    Text("📈") // Growing graph emoji
                        .font(.system(size: 30)) // Adjust size as needed
                        .foregroundColor(.black)
                    Text("View Analytics")
                        .font(.body)
                        .foregroundColor(.black)
                }
                .padding(EdgeInsets(top: 15, leading: 100, bottom: 15, trailing: 100)) // Adjust padding as needed
                .background(Color.white) // White background color
                .cornerRadius(10) // Rounded corners for the button
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.black, lineWidth: 1) // Black outline
                )
            }
            .buttonStyle(PlainButtonStyle()) // Remove default button style
            .padding() // Padding around the button
        }
    }
}

struct BoxView: View {
    var emoji: String
    var count: String
    var label: String
    
    var body: some View {
        VStack {
            Text(emoji)
                .font(.title)
            Text(count)
                .font(.title)
                .fontWeight(.bold)
            Text(label)
                .font(.title)
                .foregroundColor(.gray)
        }
        .padding(20) // Padding around the content inside the box
        .background(Color.blue.opacity(0.1)) // Adjust background color as needed
        .cornerRadius(10)
    }
}

struct GreetingView_Previews: PreviewProvider {
    static var previews: some View {
        GreetingView()
    }
}
