import SwiftUI

struct ButtonView: View {
    @State private var linksClicked = true
    @State private var coursesClicked = false
    @State private var addClicked = false
    @State private var campaignsClicked = false
    @State private var profileClicked = false

    var body: some View {
        ZStack {
            HStack(spacing: 0) {
                Button(action: {
                    linksClicked.toggle()
                    if linksClicked {
                        resetOtherButtons()
                    }
                }) {
                    VStack {
                        Text("🔗")
                        Text("Links")
                            .font(.footnote)
                            .fontWeight(.bold)
                            .foregroundColor(linksClicked ? .black : .gray) // Change text color based on state
                    }
                    .padding(.top, 20)
                    .frame(maxWidth: .infinity)
                }
                .padding(.bottom, 10)
                
                Button(action: {
                    coursesClicked.toggle()
                    if coursesClicked {
                        resetOtherButtons()
                    }
                }) {
                    VStack {
                        Text("📘")
                        Text("Courses")
                            .font(.footnote)
                            .fontWeight(.bold)
                            .foregroundColor(coursesClicked ? .black : .gray) // Change text color based on state
                    }
                    .padding(.top, 20)
                    .padding(.leading, -20)
                    .frame(maxWidth: .infinity)
                }
                .padding(.bottom, 10)
                
                Button(action: {
                    addClicked.toggle()
                    if addClicked {
                        resetOtherButtons()
                    }
                }) {
                    VStack {
                        Image(systemName: "plus.circle.fill")
                            .font(.system(size: 32))
                            .foregroundColor(.white)
                            .padding(EdgeInsets(top: 20, leading: 20, bottom: 20, trailing: 20))
                            .background(Color.blue)
                            .clipShape(RoundedRectangle(cornerRadius: 50))
                            .shadow(radius: 10)
                            .padding(5)
                    }
                    .padding(.bottom, 10)
                }
                
                Button(action: {
                    campaignsClicked.toggle()
                    if campaignsClicked {
                        resetOtherButtons()
                    }
                }) {
                    VStack {
                        Text("📢")
                        Text("Campaigns")
                            .font(.footnote)
                            .fontWeight(.bold)
                            .foregroundColor(campaignsClicked ? .black : .gray) // Change text color based on state
                    }
                    .padding(.top, 20)
                    .padding(.trailing, -20)
                    .padding(.leading, -10)
                    .frame(maxWidth: .infinity)
                }
                .padding(.bottom, 10)
                
                Button(action: {
                    profileClicked.toggle()
                    if profileClicked {
                        resetOtherButtons()
                    }
                }) {
                    VStack {
                        Text("👤")
                        Text("Profile")
                            .font(.footnote)
                            .fontWeight(.bold)
                            .foregroundColor(profileClicked ? .black : .gray) // Change text color based on state
                    }
                    .padding(.top, 20)
                    .frame(maxWidth: .infinity)
                }
                .padding(.bottom, 10)
            }
            .background(Color(UIColor.white))
            
            // Curved container around the "Add" button
            RoundedRectangle(cornerRadius: 50)
                .stroke(Color.blue, lineWidth: 2)
                .frame(width: 100, height: 100)
                .offset(x: 0, y: 50) // Adjust offset as needed
                .opacity(addClicked ? 1 : 0) // Show curve only when "Add" button is clicked
        }
    }
    
    private func resetOtherButtons() {
        coursesClicked = false
        addClicked = false
        campaignsClicked = false
        profileClicked = false
    }
}

struct ButtonView_Previews: PreviewProvider {
    static var previews: some View {
        ButtonView()
    }
}
