import SwiftUI
import SwiftyJSON

struct TabView: View {
    @State private var topLinks: [LinkItem] = []
    @State private var recentLinks: [LinkItem] = []
    @State private var selectedTab: Tab = .topLinks
    
    enum Tab {
        case topLinks
        case recentLinks
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                HStack(spacing: 0) {
                    Button(action: {
                        selectedTab = .topLinks
                        fetchLinks()
                    }) {
                        Text("Top Links")
                            .font(.headline)
                            .foregroundColor(selectedTab == .topLinks ? .white : .gray)
                            .padding(.vertical, 10)
                            .padding(.horizontal, 20)
                            .background(selectedTab == .topLinks ? Color.blue : Color.white)
                            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                    }
                    .buttonStyle(PlainButtonStyle())
                    .padding(.trailing, 10)
                    
                    Button(action: {
                        selectedTab = .recentLinks
                        fetchLinks()
                    }) {
                        Text("Recent Links")
                            .font(.headline)
                            .foregroundColor(selectedTab == .recentLinks ? .white : .gray)
                            .padding(.vertical, 10)
                            .padding(.horizontal, 20)
                            .background(selectedTab == .recentLinks ? Color.blue : Color.white)
                            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                    }
                    .buttonStyle(PlainButtonStyle())
                    .padding(.trailing, 10)
                    
                    Spacer()
                    
                    Button(action: {
                        // Action for Search
                    }) {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)
                            .padding(.vertical, 10)
                            .padding(.horizontal, 20)
                            .background(Color.white)
                            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                    }
                    .buttonStyle(PlainButtonStyle())
                }
                .padding(.horizontal, 5)
                
                // Content based on selected tab
                if selectedTab == .topLinks {
                    linkItemsView(links: topLinks)
                } else {
                    linkItemsView(links: recentLinks)
                }
            }
            .padding(.top, 30)
        }
    }
    
    private func fetchLinks() {
        guard let url = URL(string: "https://api.inopenapp.com/api/v1/dashboardNew") else {
            print("Invalid URL")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MjU5MjcsImlhdCI6MTY3NDU1MDQ1MH0.dCkW0ox8tbjJA2GgUx2UEwNlbTZ7Rr38PVFJevYcXFI", forHTTPHeaderField: "Authorization")
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error: \(error.localizedDescription)")
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse else {
                print("Invalid response")
                return
            }
            
            guard (200...299).contains(httpResponse.statusCode) else {
                print("HTTP response error: \(httpResponse.statusCode)")
                return
            }
            
            guard let data = data else {
                print("No data received")
                return
            }
            
            let json = JSON(data)
            let topLinksJson = json["data"]["top_links"]
            let recentLinksJson = json["data"]["recent_links"]
            
            var topLinksArray: [LinkItem] = []
            var recentLinksArray: [LinkItem] = []
            
            for (_, linkJson) in topLinksJson {
                if let linkItem = parseLinkItem(from: linkJson) {
                    topLinksArray.append(linkItem)
                }
            }
            
            for (_, linkJson) in recentLinksJson {
                if let linkItem = parseLinkItem(from: linkJson) {
                    recentLinksArray.append(linkItem)
                }
            }
            
            DispatchQueue.main.async {
                topLinks = topLinksArray
                recentLinks = recentLinksArray
            }
        }.resume()
    }
    
    private func parseLinkItem(from json: JSON) -> LinkItem? {
        guard let urlID = json["url_id"].int,
              let webLink = json["web_link"].string,
              let title = json["title"].string,
              let totalClicks = json["total_clicks"].int,
              let originalImage = json["original_image"].string,
              let timesAgo = json["times_ago"].string else {
            return nil
        }

        return LinkItem(urlID: urlID, webLink: webLink, title: title, totalClicks: totalClicks, originalImage: originalImage, timesAgo: timesAgo)
    }

    private func linkItemsView(links: [LinkItem]) -> some View {
        VStack(spacing: 20) { // Adjust the spacing here as needed
            ForEach(links, id: \.urlID) { link in
                RectangleWithImage(link: link)
            }
        }
    }
}


struct RectangleWithImage: View {
    var link: LinkItem
    @State private var showCopiedAlert = false
    
    var body: some View {
        VStack(spacing: 0) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(Color.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.blue, lineWidth: 2)
                    )

                HStack(spacing: 10) {
                    // Image
                    if let imageUrl = URL(string: link.originalImage),
                       let imageData = try? Data(contentsOf: imageUrl),
                       let uiImage = UIImage(data: imageData) {
                        Image(uiImage: uiImage)
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 80, height: 80) // Adjust size as needed
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                    }

                    // Title
                    VStack(alignment: .leading, spacing: 5) {
                        Text(link.title)
                            .font(.footnote)
                            .foregroundColor(.black)
                        
                        Text(link.timesAgo)
                            .font(.footnote)
                            .foregroundColor(.gray)
                    }
                    .padding(.trailing)

                    Spacer()

                    // Total Clicks
                    VStack {
                        Text("\(link.totalClicks)")
                            .font(.subheadline)
                            .fontWeight(.bold)
                            .foregroundColor(.black)
                        Text("Clicks")
                            .font(.footnote)
                            .foregroundColor(.gray)
                    }
                }
                .padding(10)
            }
            .frame(maxWidth: .infinity)
            
            // Web Link
            HStack {
                Text(link.webLink)
                    .font(.body)
                    .foregroundColor(.blue)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .onTapGesture {
                        UIPasteboard.general.string = link.webLink
                        showCopiedAlert = true
                    }
                Button(action: {
                    UIPasteboard.general.string = link.webLink
                    showCopiedAlert = true
                }) {
                    Image(systemName: "doc.on.doc")
                        .foregroundColor(.blue)
                }
                .padding(.trailing, 10)
            }
            .padding(.horizontal)
        }
        .alert(isPresented: $showCopiedAlert) {
            Alert(title: Text("Copied!"), message: Text("The link has been copied to the clipboard."), dismissButton: .default(Text("OK")))
        }
    }
}


struct LinkItem: Identifiable {
    let id = UUID()
    let urlID: Int
    let webLink: String
    let title: String
    let totalClicks: Int
    let originalImage: String
    let timesAgo: String // Add this property
}


struct TabView_Previews: PreviewProvider {
    static var previews: some View {
        TabView()
    }
}
