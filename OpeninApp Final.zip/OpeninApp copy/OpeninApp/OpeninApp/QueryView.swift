import SwiftUI

struct QueryView: View {
    var body: some View {
        VStack(spacing: 20) {
            Button(action: {
                // Action for tapping the button
                // You can add your action here, like opening a FAQ section
            }) {
                HStack(spacing: 10) {
                    Text("❓") // Question mark emoji
                        .padding(.leading, -30)
                        .font(.system(size: 30)) // Adjust size as needed
                        .foregroundColor(.white)
                    Text("Frequently Asked Questions")
                        .font(.title3)
                        .foregroundColor(.white)
                }
                .padding(EdgeInsets(top: 15, leading: 40, bottom: 15, trailing: 40)) // Adjust padding as needed
                .background(Color.blue) // Blue background color
                .cornerRadius(10) // Rounded corners for the button
            }
            .buttonStyle(PlainButtonStyle()) // Remove default button style
            .padding(.bottom, 20)
            .padding(.top, -70)
            
            Spacer() // Add spacer to push the button to the top
        }
        .padding() // Padding for the VStack
    }
}

struct QueryView_Previews: PreviewProvider {
    static var previews: some View {
        QueryView()
            .previewLayout(.sizeThatFits)
            .padding()
    }
}
