import SwiftUI


struct DashboardView: View {
    var body: some View {
        ZStack {
            ScrollView {
                VStack(spacing: 0) {
                    HeaderView()
                    VStack(spacing: 0) {
                        GreetingView()
                            .padding(.top, 10)
        
                        // Add padding to position it below the blue tab
                        Spacer() // Add a spacer to push the TabView to the bottom
                        TabView()
                        ContactView()
                            .padding(.top, 50)
                        QueryView()
                            .padding(.top, 50)
                        Spacer()
                    }
                    .padding()
                    .background(Color(UIColor.systemGray6))
                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous)) // Rounded corners for the white screen
                    .offset(y: -20) // Offset the white screen upward to overlap the blue tab
                }
            }
            
            VStack {
                Spacer()
                ButtonView()
            }
            .edgesIgnoringSafeArea(.bottom) // Ignore safe area to extend ButtonView to the bottom of the screen
        }
    }
}
