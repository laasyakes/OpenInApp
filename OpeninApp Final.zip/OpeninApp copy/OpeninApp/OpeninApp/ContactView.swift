import SwiftUI

struct ContactView: View {
    var body: some View {
        VStack(spacing: 20) {
            // New button with white background and black outline
            Button(action: {
                // Action for tapping the button
                // You can add your action here
            }) {
                HStack(spacing: 10) {
                    Text("🔗") // Link emoji
                        .font(.system(size: 30)) // Adjust size as needed
                        .foregroundColor(.black)
                    Text("View all Links")
                        .font(.title3)
                        .foregroundColor(.black)
                }
                .padding(EdgeInsets(top: 15, leading: 100, bottom: 15, trailing: 100)) // Adjust padding as needed
                .background(Color.white) // White background color
                .cornerRadius(10) // Rounded corners for the button
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.black, lineWidth: 1) // Black outline
                )
            }
            .buttonStyle(PlainButtonStyle()) // Remove default button style
            
            // Add some spacing between buttons
            Spacer().frame(height: 10)
            
            // Existing button
            Button(action: {
                // Action for tapping the button
                // You can add your action here, like opening a WhatsApp chat
            }) {
                HStack(spacing: 10) {
                    Text("📞") // Text emoji
                        .padding(.leading, -40)
                        .font(.system(size: 30)) // Adjust size as needed
                        .foregroundColor(.white)
                    Text("Talk with Us")
                        .font(.title3)
                        .foregroundColor(.white)
                }
                .padding(EdgeInsets(top: 15, leading: 120, bottom: 15, trailing: 120)) // Adjust padding as needed
                .background(Color.green) // Green background color
                .cornerRadius(10) // Rounded corners for the button
            }
            .buttonStyle(PlainButtonStyle()) // Remove default button style
        }
        .padding() // Padding for the VStack
    }
}

struct ContactView_Previews: PreviewProvider {
    static var previews: some View {
        ContactView()
            .previewLayout(.sizeThatFits)
            .padding()
    }
}
