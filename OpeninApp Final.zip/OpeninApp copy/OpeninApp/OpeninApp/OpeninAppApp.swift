//
//  OpeninAppApp.swift
//  OpeninApp
//
//  Created by Laasya Kesanapalli on 24/04/24.
//

import SwiftUI

@main
struct OpeninAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
